from ui.ui import Ui

def main():
    ui = Ui()
    ui.runUi()

if __name__ == "__main__":
    main()
