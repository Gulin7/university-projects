#pragma once
class Tests
{
public:
	static void testDynamicVector();
	static void testLinkedList();
};

