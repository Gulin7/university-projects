#include "Service.h"
#include <string.h>

Service createService(PlanetRepo* r)
{
	Service s;
	s.repo = r;

	return s;
}

int addPlanet(Service* s, char name[], char type[], double distanceFromEarth)
{
	Planet p = createPlanet(name, type, distanceFromEarth);
	
	int res = add(s->repo, p);
	return res;
}

PlanetRepo* getRepo(Service* s)
{
	return s->repo;
}

PlanetRepo filterByType(Service* s, char type[])
{
	PlanetRepo res = createRepo();

	// add the planets having the given type to "res" created above and return res
	// TODO

	return res;
}