#include "PlanetRepository.h"
#include "UI.h"
#include <crtdbg.h>

int main()
{
	// tests will not pass unless all functions are correctly implemented
	// testsPlanetRepo();

	PlanetRepo repo = createRepo();
	Service serv = createService(&repo);
	
	addPlanet(&serv, "Wolf 1061 c", "terrestrial", 13.8);
	addPlanet(&serv, "HAT-P-26b", "Neptune-like", 450);
	addPlanet(&serv, "Proxima Centauri b", "terrestrial", 4.2);
	addPlanet(&serv, "K2-18b", "super-Earth", 111);
	
	UI ui = createUI(&serv);

	startUI(&ui);

	_CrtDumpMemoryLeaks();

	return 0;
}