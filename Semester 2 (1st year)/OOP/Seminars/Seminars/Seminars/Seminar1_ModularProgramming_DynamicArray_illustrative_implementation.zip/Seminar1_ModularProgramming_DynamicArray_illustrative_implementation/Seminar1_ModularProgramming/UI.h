#pragma once
#include "Service.h"

typedef struct
{
	Service* serv;
} UI;

UI createUI(Service* s);

void startUI(UI* ui);