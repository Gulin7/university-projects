#include "Service.h"
#include <stdlib.h>
#include <string.h>

Service* createService(PlanetRepo* r)
{
	Service* s = (Service*)malloc(sizeof(Service));
	if (s == NULL)
		return NULL;
	s->repo = r;

	return s;
}

void destroyService(Service* s)
{
	// first destroy the repository inside
	destroyRepo(s->repo);
	// then free the memory
	free(s);
}

int addPlanet(Service* s, char* name, char* type, double distanceFromEarth)
{
	Planet* p = createPlanet(name, type, distanceFromEarth);
	
	int res = add(s->repo, p);
	// if the planet was not added - destroy it (as it will not be destroyed by the repository)
	if (res == 0)
		destroyPlanet(p);

	return res;
}

PlanetRepo* getRepo(Service* s)
{
	return s->repo;
}

PlanetRepo* filterByType(Service* s, char type[])
{
	PlanetRepo* res = createRepo();

	if (strcmp(type, "null") == 0)
	{
		// what should we do here?
	}

	// for each planet that fulfills the condition, create a copy and add it to "res"
	// why should we create a copy?

	// TODO

	return res;
}