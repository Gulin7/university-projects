#include "Observer_stub.h"

Observer_stub::Observer_stub(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

Observer_stub::~Observer_stub()
{}
