#include "ModelView_stub.h"

ModelView_stub::ModelView_stub(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

ModelView_stub::~ModelView_stub()
{}
