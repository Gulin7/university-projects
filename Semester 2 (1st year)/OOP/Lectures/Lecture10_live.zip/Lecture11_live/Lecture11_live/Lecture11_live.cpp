#include "Lecture11_live.h"

Lecture11_live::Lecture11_live(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

Lecture11_live::~Lecture11_live()
{}
