#include "Lecture11_custom_models.h"

Lecture11_custom_models::Lecture11_custom_models(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

Lecture11_custom_models::~Lecture11_custom_models()
{}
